
#include "NewScene.h"
#include "level1.h"
#include "level2.h"
#include "level3.h"
USING_NS_CC;

Scene* NewScene::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = NewScene::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
bool NewScene::init()
{
	//////////////////////////////
	// 1. super init first
	if (!Layer::init())
	{
		return false;
	}

	Size visibleSize = Director::getInstance()->getVisibleSize();
	Point origin = Director::getInstance()->getVisibleOrigin();
	mySprite = Sprite::create("levels.png");

	mySprite->setPosition(Point((visibleSize.width / 2)-10 + origin.x, (visibleSize.height / 2)+30 + origin.y));

	this->addChild(mySprite);

	auto menu_item_1 = MenuItemFont::create("level 1", CC_CALLBACK_1(NewScene::level1, this));
	auto menu_item_2 = MenuItemFont::create("level 2", CC_CALLBACK_1(NewScene::level2, this));
	auto menu_item_3 = MenuItemFont::create("level 3", CC_CALLBACK_1(NewScene::level3, this));
	auto menu_item_4 = MenuItemImage::create("GoBack.png","GoBack.png", CC_CALLBACK_1(NewScene::GoBack, this));
	menu_item_4->setPosition(Point(visibleSize.width / 2, (visibleSize.height / 5) + origin.y *1));
	menu_item_3->setPosition(Point(visibleSize.width / 2, (visibleSize.height / 5) * 2));
	menu_item_2->setPosition(Point(visibleSize.width / 2, (visibleSize.height / 2)+15 * 3));
	menu_item_1->setPosition(Point(visibleSize.width / 2, (visibleSize.height / 2)+40 *4));

	auto *menu = Menu::create(menu_item_1, menu_item_2, menu_item_3, menu_item_4, NULL);
	menu->setPosition(Point(0,0));
	this->addChild(menu);

	return true;
}

void NewScene::GoBack(cocos2d::Ref *pSender)
{
	CCLOG("Go Back");
	Director::getInstance()->popScene();
}
void NewScene::level1(cocos2d::Ref *pSender)
{
	CCLOG("level 1");
	auto scene = level1::createScene();

	Director::getInstance()->pushScene(scene);
}

void NewScene::level2(cocos2d::Ref *pSender)
{
	CCLOG("level 2");
	auto scene = level2::createScene();

	Director::getInstance()->pushScene(scene);
}

void NewScene::level3(cocos2d::Ref *pSender)
{
	CCLOG("level 3");
		auto scene = level3::createScene();

	Director::getInstance()->pushScene(scene);
}
void NewScene::menuCloseCallback(Ref* pSender)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WP8) || (CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
	MessageBox("You pressed the close button. Windows Store Apps do not implement a close button.", "Alert");
	return;
#endif

	Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	exit(0);
#endif
}