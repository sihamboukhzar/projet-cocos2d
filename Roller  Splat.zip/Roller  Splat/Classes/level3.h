
#ifndef __LEVEL3_SCENE_H__
#define __LEVEL3_SCENE_H__

#include "cocos2d.h"

class level3 : public cocos2d::Layer
{
public:
	static cocos2d::Scene* createScene();

	virtual bool init();

	// a selector callback
	void menuCloseCallback(cocos2d::Ref* pSender);

	// implement the "static create()" method manually
	CREATE_FUNC(level3);
	cocos2d::Sprite *mySprite;
	cocos2d::DrawNode *draw;
	void GoBack(Ref *pSender);
private:
	cocos2d::PhysicsWorld *sceneWorld;

	void SetPhysicsWorld(cocos2d::PhysicsWorld *world) { sceneWorld = world; };
};

#endif // __HELLOWORLD_SCENE_H__
