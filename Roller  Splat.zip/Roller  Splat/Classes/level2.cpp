
#include "level2.h"
USING_NS_CC;

Scene* level2::createScene()
{
	// 'scene' is an autorelease object
	//auto scene = Scene::create();
	auto scene = Scene::createWithPhysics();
	//scene->getPhysicsWorld()->setDebugDrawMask(PhysicsWorld::DEBUGDRAW_ALL);
	scene->getPhysicsWorld()->setGravity(Vec2(0, 0));//conteur
	// 'layer' is an autorelease object
	auto layer = level2::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
bool level2::init()
{
	//////////////////////////////
	// 1. super init first
	if (!Layer::init())
	{
		return false;
	}

	Size visibleSize = Director::getInstance()->getVisibleSize();
	Point origin = Director::getInstance()->getVisibleOrigin();
	//bacground
	mySprite = Sprite::create("level2.png");
	mySprite->setPosition(Point((visibleSize.width / 2) + origin.x, (visibleSize.height / 2)+ origin.y));
	this->addChild(mySprite);


	//creation de physical boday
	auto edgeBody = PhysicsBody::createEdgeBox(visibleSize/3, PHYSICSBODY_MATERIAL_DEFAULT, 3);
	auto edgeNode = Node::create();
	edgeNode->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y+10));
	edgeNode->setPhysicsBody(edgeBody);
	this->addChild(edgeNode);
	//ballon
	mySprite = Sprite::create("ball.png");
	mySprite->setPosition(Point((visibleSize.width / 2)-80 + origin.x, (visibleSize.height / 2)-70 + origin.y));
	auto spriteBody = PhysicsBody::createCircle(mySprite->getContentSize().width / 3, PhysicsMaterial(0, 1, 0));
	spriteBody->setCollisionBitmask(1);
	spriteBody->setContactTestBitmask(true);
	mySprite->setPhysicsBody(spriteBody);
	this->addChild(mySprite);
	//les fleches
	auto eventListener = EventListenerKeyboard::create();
	eventListener->onKeyPressed = [=](EventKeyboard::KeyCode KeyCode, Event* event) {
		int offsetX = 0, offsetY = 0;
		switch (KeyCode) {

		case EventKeyboard::KeyCode::KEY_LEFT_ARROW:

			// l3bar bach kimchi 200 px
			offsetX = -20;
			break;
		case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
			offsetX = 20;
			break;
		case EventKeyboard::KeyCode::KEY_UP_ARROW:

			offsetY = 20;
			break;
		case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
			offsetY = -20;
			break;
		}

		auto moveTo = MoveTo::create(0.3, Vec2(event->getCurrentTarget()->getPositionX() + offsetX, event->getCurrentTarget()->getPositionY() + offsetY));
		event->getCurrentTarget()->runAction(moveTo);
		draw = DrawNode::create();
		draw->drawSegment(Vec2(event->getCurrentTarget()->getPositionX(), event->getCurrentTarget()->getPositionY()), Vec2(event->getCurrentTarget()->getPositionX() + offsetX, event->getCurrentTarget()->getPositionY() + offsetY), 20, Color4F::MAGENTA);
		this->addChild(draw, 0);
	};
	this->_eventDispatcher->addEventListenerWithSceneGraphPriority(eventListener, mySprite);

	auto menu_item_2 = MenuItemImage::create("GoBack.png", "GoBack.png", CC_CALLBACK_1(level2::ImageButton, this));


	menu_item_2->setPosition(Point(visibleSize.width / 2, (visibleSize.height / 5) * 1));


	auto *menu = Menu::create( menu_item_2, NULL);
	menu->setPosition(Point(0, 0));
	this->addChild(menu);


	return true;
}


void level2::ImageButton(cocos2d::Ref *pSender)
{
	CCLOG("IMAGE Button");
	Director::getInstance()->popScene();
}

void level2::menuCloseCallback(Ref* pSender)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WP8) || (CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
	MessageBox("You pressed the close button. Windows Store Apps do not implement a close button.", "Alert");
	return;
#endif

	Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	exit(0);
#endif
}