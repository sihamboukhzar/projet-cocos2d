#ifndef __NEW_SCENE_H__
#define __NEW_SCENE_H__
#include "cocos2d.h"
//class newScene
class NewScene : public cocos2d::Layer
{
public:
	static cocos2d::Scene* createScene();

	virtual bool init();

	// a selector callback
	void menuCloseCallback(cocos2d::Ref* pSender);

	// implement the "static create()" method manually
	CREATE_FUNC(NewScene);

	cocos2d::Sprite *mySprite;
	//declaration des methodes
	void GoBack(Ref *pSender);
	void level1(Ref *pSender);
	void level2(Ref *pSender);
	void level3(Ref *pSender);
};

#endif // __HELLOWORLD_SCENE_H__